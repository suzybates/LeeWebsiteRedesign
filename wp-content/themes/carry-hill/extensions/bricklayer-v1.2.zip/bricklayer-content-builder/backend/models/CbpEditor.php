<?php
if (!class_exists('CbpEditor')) :

    /**
     * @author Parmenides <krivinarius@gmail.com>
     */
    class CbpEditor
    {
        public static $mce_locale;
//	private static $mce_settings = array();
//	private static $qt_settings = array();
        private static $plugins = array();
        private static $ext_plugins;
        private static $first_init;
        private static $mce_settings = null;
        private static $qt_settings  = null;
        private static $baseurl;

        public static function init()
        {
            $ajax = new CbpAjax();
            $ajax->setAjaxCallback(array(__CLASS__, 'cbpEditorHtmlAjax'));
            $ajax->run();
        }
        /*
         * AJAX Call Used to Generate the WP Editor
         */

        public static function cbpEditorHtmlAjax()
        {

            // do array merge here with custom settings
            /*
              array(
              'wpautop' => true,
              'media_buttons' => true,
              'textarea_name' => $editor_id,
              'textarea_rows' => 20,
              'tabindex' => '',
              'tabfocus_elements' => ':prev,:next',
              'editor_css' => '',
              'editor_class' => '',
              'teeny' => false,
              'dfw' => false,
              'tinymce' => true,
              'quicktags' => true
              );
             */
            $content = stripslashes($_POST['content']);
            wp_editor($content, $_POST['id'], array(
                'textarea_name' => $_POST['textarea_name']
            ));
            self::editor_settings($_POST['id'], array());
            $mce_init = self::get_mce_init($_POST['id']);
            $qt_init  = self::get_qt_init($_POST['id']);
            ?>
            <script type="text/javascript">
                tinyMCEPreInit.mceInit = jQuery.extend( tinyMCEPreInit.mceInit, <?php echo $mce_init ?>);
                tinyMCEPreInit.qtInit = jQuery.extend( tinyMCEPreInit.qtInit, <?php echo $qt_init ?>);
            </script>
            <?php
            die();
        }

        public static function renderEditor($content, $editor_id, $settings = array())
        {

            $set = wp_parse_args($settings, array(
                'wpautop'           => true, // use wpautop?
                'media_buttons'     => true, // show insert/upload button(s)
                'textarea_name'     => $editor_id, // set the textarea name to something different, square brackets [] can be used here
                'textarea_rows'     => 20,
                'tabindex'          => '',
                'tabfocus_elements' => ':prev,:next', // the previous and next element ID to move the focus to when pressing the Tab key in TinyMCE
                'editor_css'        => '', // intended for extra styles for both visual and Text editors buttons, needs to include the <style> tags, can use "scoped".
                'editor_class'      => '', // add extra class(es) to the editor textarea
                'teeny'             => false, // output the minimal editor config used in Press This
                'dfw'               => false, // replace the default fullscreen with DFW (needs specific DOM elements and css)
                'tinymce'           => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
                'quicktags'         => true // load Quicktags, can be used to pass settings directly to Quicktags using an array()
                    ));


            $content = stripslashes($content);
            wp_editor($content, $editor_id, $set);
            self::editor_settings($editor_id, $set);

            $mce_init = self::get_mce_init($editor_id);
            $qt_init  = self::get_qt_init($editor_id);
            ?>
            <script type="text/javascript">
                tinyMCEPreInit.mceInit = jQuery.extend( tinyMCEPreInit.mceInit, <?php echo $mce_init ?>);
                tinyMCEPreInit.qtInit = jQuery.extend( tinyMCEPreInit.qtInit, <?php echo $qt_init ?>);                        
                                    
                tinyMCE.init(tinyMCEPreInit.mceInit['<?php echo $editor_id; ?>']);
                try {
                    quicktags(tinyMCEPreInit.qtInit['<?php echo $editor_id; ?>']);
                } catch (e) {}
                                    
            </script>
            <?php
        }

        public static function getJsInit($editor_id, $settings = array())
        {

            $set = wp_parse_args($settings, array(
                'wpautop'           => true, // use wpautop?
                'media_buttons'     => true, // show insert/upload button(s)
                'textarea_name'     => $editor_id, // set the textarea name to something different, square brackets [] can be used here
                'textarea_rows'     => 20,
                'tabindex'          => '',
                'tabfocus_elements' => ':prev,:next', // the previous and next element ID to move the focus to when pressing the Tab key in TinyMCE
                'editor_css'        => '', // intended for extra styles for both visual and Text editors buttons, needs to include the <style> tags, can use "scoped".
                'editor_class'      => '', // add extra class(es) to the editor textarea
                'teeny'             => false, // output the minimal editor config used in Press This
                'dfw'               => false, // replace the default fullscreen with DFW (needs specific DOM elements and css)
                'tinymce'           => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
                'quicktags'         => true // load Quicktags, can be used to pass settings directly to Quicktags using an array()
                    ));


            self::editor_settings($editor_id, $set);

            $mce_init = self::get_mce_init($editor_id);
            $qt_init  = self::get_qt_init($editor_id);
            ?>
            
              tinyMCEPreInit.mceInit = jQuery.extend( tinyMCEPreInit.mceInit, <?php echo $mce_init ?>);
              tinyMCEPreInit.qtInit = jQuery.extend( tinyMCEPreInit.qtInit, <?php echo $qt_init ?>);

              tinyMCE.init(tinyMCEPreInit.mceInit['<?php echo $editor_id; ?>']);
              try {
              quicktags(tinyMCEPreInit.qtInit['<?php echo $editor_id; ?>']);
              } catch (e) {}
            

            <?php
        }

        public static function quicktags_settings($qtInit, $editor_id)
        {
            self::$qt_settings = $qtInit;
            return $qtInit;
        }

        public static function tiny_mce_before_init($mceInit, $editor_id)
        {
            self::$mce_settings = $mceInit;
            return $mceInit;
        }
        /*
         * Code coppied from _WP_Editors class (modified a little)
         */

        private static function get_qt_init($editor_id)
        {
            $qtInit = '';
            if (!empty(self::$qt_settings)) {
                foreach (self::$qt_settings as $editor_id => $init) {
                    $options = self::_parse_init($init);
                    $qtInit .= "'$editor_id':{$options},";
                }
                $qtInit  = '{' . trim($qtInit, ',') . '}';
            } else {
                $qtInit = '{}';
            }
            return $qtInit;
        }

        private static function get_mce_init($editor_id)
        {
            $mceInit = '';
            if (!empty(self::$mce_settings)) {
                foreach (self::$mce_settings as $editor_id => $init) {
                    $options = self::_parse_init($init);
                    $mceInit .= "'$editor_id':{$options},";
                }
                $mceInit = '{' . trim($mceInit, ',') . '}';
            } else {
                $mceInit = '{}';
            }
            return $mceInit;
        }

        private static function _parse_init($init)
        {
            $options = '';

            foreach ($init as $k => $v) {
                if (is_bool($v)) {
                    $val = $v ? 'true' : 'false';
                    $options .= $k . ':' . $val . ',';
                    continue;
                } elseif (!empty($v) && is_string($v) && ( ('{' == $v{0} && '}' == $v{strlen($v) - 1}) || ('[' == $v{0} && ']' == $v{strlen($v) - 1}) || preg_match('/^\(?function ?\(/', $v) )) {
                    $options .= $k . ':' . $v . ',';
                    continue;
                }
                $options .= $k . ':"' . $v . '",';
            }

            return '{' . trim($options, ' ,') . '}';
        }

        public static function editor_settings($editor_id, $set)
        {
            $first_run = false;



            if ((bool) $set['quicktags']) {

                $qtInit = array(
                    'id'      => $editor_id,
                    'buttons' => ''
                );

                if (is_array($set['quicktags']))
                    $qtInit = array_merge($qtInit, $set['quicktags']);

                if (empty($qtInit['buttons']))
                    $qtInit['buttons'] = 'strong,em,link,block,del,ins,img,ul,ol,li,code,more,close';

                if ($set['dfw'])
                    $qtInit['buttons'] .= ',fullscreen';

                $qtInit = apply_filters('quicktags_settings', $qtInit, $editor_id);
                self::$qt_settings[$editor_id] = $qtInit;

//			self::$qt_buttons = array_merge( self::$qt_buttons, explode(',', $qtInit['buttons']) );
            }

            if ((bool) $set['tinymce']) {

                if (empty(self::$first_init)) {
                    self::$baseurl = includes_url('js/tinymce');
                    self::$mce_locale = $mce_locale  = ( '' == get_locale() ) ? 'en' : strtolower(substr(get_locale(), 0, 2)); // only ISO 639-1
                    $no_captions = (bool) apply_filters('disable_captions', '');
                    $plugins     = array('inlinepopups', 'tabfocus', 'paste', 'media', 'fullscreen', 'wordpress', 'wpeditimage', 'wpgallery', 'wplink', 'wpdialogs');
                    $first_run   = true;
                    $ext_plugins = '';

                    if ($set['teeny']) {
                        self::$plugins = $plugins = apply_filters('teeny_mce_plugins', array('inlinepopups', 'fullscreen', 'wordpress', 'wplink', 'wpdialogs'), $editor_id);
                    } else {
                        /*
                          The following filter takes an associative array of external plugins for TinyMCE in the form 'plugin_name' => 'url'.
                          It adds the plugin's name to TinyMCE's plugins init and the call to PluginManager to load the plugin.
                          The url should be absolute and should include the js file name to be loaded. Example:
                          array( 'myplugin' => 'http://my-site.com/wp-content/plugins/myfolder/mce_plugin.js' )
                          If the plugin uses a button, it should be added with one of the "$mce_buttons" filters.
                         */
                        $mce_external_plugins = apply_filters('mce_external_plugins', array());

                        if (!empty($mce_external_plugins)) {

                            /*
                              The following filter loads external language files for TinyMCE plugins.
                              It takes an associative array 'plugin_name' => 'path', where path is the
                              include path to the file. The language file should follow the same format as
                              /tinymce/langs/wp-langs.php and should define a variable $strings that
                              holds all translated strings.
                              When this filter is not used, the function will try to load {mce_locale}.js.
                              If that is not found, en.js will be tried next.
                             */
                            $mce_external_languages = apply_filters('mce_external_languages', array());

                            $loaded_langs = array();
                            $strings = '';

                            if (!empty($mce_external_languages)) {
                                foreach ($mce_external_languages as $name => $path) {
                                    if (@is_file($path) && @is_readable($path)) {
                                        include_once($path);
                                        $ext_plugins .= $strings . "\n";
                                        $loaded_langs[] = $name;
                                    }
                                }
                            }

                            foreach ($mce_external_plugins as $name => $url) {

                                $url = set_url_scheme($url);

                                $plugins[] = '-' . $name;

                                $plugurl = dirname($url);
                                $strings = $str1    = $str2    = '';
                                if (!in_array($name, $loaded_langs)) {
                                    $path = str_replace(content_url(), '', $plugurl);
                                    $path = WP_CONTENT_DIR . $path . '/langs/';

                                    if (function_exists('realpath'))
                                        $path = trailingslashit(realpath($path));

                                    if (@is_file($path . $mce_locale . '.js'))
                                        $strings .= @file_get_contents($path . $mce_locale . '.js') . "\n";

                                    if (@is_file($path . $mce_locale . '_dlg.js'))
                                        $strings .= @file_get_contents($path . $mce_locale . '_dlg.js') . "\n";

                                    if ('en' != $mce_locale && empty($strings)) {
                                        if (@is_file($path . 'en.js')) {
                                            $str1 = @file_get_contents($path . 'en.js');
                                            $strings .= preg_replace('/([\'"])en\./', '$1' . $mce_locale . '.', $str1, 1) . "\n";
                                        }

                                        if (@is_file($path . 'en_dlg.js')) {
                                            $str2 = @file_get_contents($path . 'en_dlg.js');
                                            $strings .= preg_replace('/([\'"])en\./', '$1' . $mce_locale . '.', $str2, 1) . "\n";
                                        }
                                    }

                                    if (!empty($strings))
                                        $ext_plugins .= "\n" . $strings . "\n";
                                }

                                $ext_plugins .= 'tinyMCEPreInit.load_ext("' . $plugurl . '", "' . $mce_locale . '");' . "\n";
                                $ext_plugins .= 'tinymce.PluginManager.load("' . $name . '", "' . $url . '");' . "\n";
                            }
                        }

                        $plugins = array_unique(apply_filters('tiny_mce_plugins', $plugins));
                    }

                    if ($set['dfw'])
                        $plugins[] = 'wpfullscreen';

                    self::$plugins = $plugins;
                    self::$ext_plugins = $ext_plugins;

                    if (in_array('spellchecker', $plugins)) {
                        /*
                          translators: These languages show up in the spellchecker drop-down menu, in the order specified, and with the first
                          language listed being the default language. They must be comma-separated and take the format of name=code, where name
                          is the language name (which you may internationalize), and code is a valid ISO 639 language code. Please test the
                          spellchecker with your values.
                         */
                        $mce_spellchecker_languages = __('English=en,Danish=da,Dutch=nl,Finnish=fi,French=fr,German=de,Italian=it,Polish=pl,Portuguese=pt,Spanish=es,Swedish=sv');

                        /*
                          The following filter allows localization scripts to change the languages displayed in the spellchecker's drop-down menu.
                          By default it uses Google's spellchecker API, but can be configured to use PSpell/ASpell if installed on the server.
                          The + sign marks the default language. More: http://www.tinymce.com/wiki.php/Plugin:spellchecker.
                         */
                        $mce_spellchecker_languages = apply_filters('mce_spellchecker_languages', '+' . $mce_spellchecker_languages);
                    }

                    self::$first_init = array(
                        'mode'                              => 'exact',
                        'width'                             => '100%',
                        'theme'                             => 'advanced',
                        'skin'                              => 'wp_theme',
                        'language'                          => self::$mce_locale,
                        'theme_advanced_toolbar_location'   => 'top',
                        'theme_advanced_toolbar_align'      => 'left',
                        'theme_advanced_statusbar_location' => 'bottom',
                        'theme_advanced_resizing'           => true,
                        'theme_advanced_resize_horizontal'  => false,
                        'dialog_type'                       => 'modal',
                        'formats'                           => "{
						alignleft : [
							{selector : 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li', styles : {textAlign : 'left'}},
							{selector : 'img,table', classes : 'alignleft'}
						],
						aligncenter : [
							{selector : 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li', styles : {textAlign : 'center'}},
							{selector : 'img,table', classes : 'aligncenter'}
						],
						alignright : [
							{selector : 'p,h1,h2,h3,h4,h5,h6,td,th,div,ul,ol,li', styles : {textAlign : 'right'}},
							{selector : 'img,table', classes : 'alignright'}
						],
						strikethrough : {inline : 'del'}
					}",
                        'relative_urls'                     => false,
                        'remove_script_host'                => false,
                        'convert_urls'                      => false,
                        'remove_linebreaks'                 => true,
                        'gecko_spellcheck'                  => true,
                        'fix_list_elements'                 => true,
                        'keep_styles'                       => false,
                        'entities'                          => '38,amp,60,lt,62,gt',
                        'accessibility_focus'               => true,
                        'media_strict'                      => false,
                        'paste_remove_styles'               => true,
                        'paste_remove_spans'                => true,
                        'paste_strip_class_attributes'      => 'all',
                        'paste_text_use_dialog'             => true,
                        'webkit_fake_resize'                => false,
                        'preview_styles'                    => 'font-family font-weight text-decoration text-transform',
                        'schema'                            => 'html5',
                        'wpeditimage_disable_captions'      => $no_captions,
                        'wp_fullscreen_content_css'         => self::$baseurl . '/plugins/wpfullscreen/css/wp-fullscreen.css',
                        'plugins'                           => implode(',', $plugins)
                    );

                    if (in_array('spellchecker', $plugins)) {
                        self::$first_init['spellchecker_rpc_url'] = self::$baseurl . '/plugins/spellchecker/rpc.php';
                        self::$first_init['spellchecker_languages'] = $mce_spellchecker_languages;
                    }

                    // load editor_style.css if the current theme supports it
                    if (!empty($GLOBALS['editor_styles']) && is_array($GLOBALS['editor_styles'])) {
                        $editor_styles = $GLOBALS['editor_styles'];

                        $mce_css = array();
                        $editor_styles = array_unique(array_filter($editor_styles));
                        $style_uri     = get_stylesheet_directory_uri();
                        $style_dir     = get_stylesheet_directory();

                        // Support externally referenced styles (like, say, fonts).
                        foreach ($editor_styles as $key => $file) {
                            if (preg_match('~^(https?:)?//~', $file)) {
                                $mce_css[] = esc_url_raw($file);
                                unset($editor_styles[$key]);
                            }
                        }

                        // Look in a parent theme first, that way child theme CSS overrides.
                        if (is_child_theme()) {
                            $template_uri = get_template_directory_uri();
                            $template_dir = get_template_directory();

                            foreach ($editor_styles as $key => $file) {
                                if ($file && file_exists("$template_dir/$file"))
                                    $mce_css[] = "$template_uri/$file";
                            }
                        }

                        foreach ($editor_styles as $file) {
                            if ($file && file_exists("$style_dir/$file"))
                                $mce_css[] = "$style_uri/$file";
                        }

                        $mce_css = implode(',', $mce_css);
                    } else {
                        $mce_css = '';
                    }

                    $mce_css = trim(apply_filters('mce_css', $mce_css), ' ,');

                    if (!empty($mce_css))
                        self::$first_init['content_css'] = $mce_css;
                }

                if ($set['teeny']) {
                    $mce_buttons = apply_filters('teeny_mce_buttons', array('bold', 'italic', 'underline', 'blockquote', 'strikethrough', 'bullist', 'numlist', 'justifyleft', 'justifycenter', 'justifyright', 'undo', 'redo', 'link', 'unlink', 'fullscreen'), $editor_id);
                    $mce_buttons_2 = $mce_buttons_3 = $mce_buttons_4 = array();
                } else {
                    $mce_buttons = apply_filters('mce_buttons', array('bold', 'italic', 'strikethrough', 'bullist', 'numlist', 'blockquote', 'justifyleft', 'justifycenter', 'justifyright', 'link', 'unlink', 'wp_more', 'spellchecker', 'fullscreen', 'wp_adv'), $editor_id);
                    $mce_buttons_2 = apply_filters('mce_buttons_2', array('formatselect', 'underline', 'justifyfull', 'forecolor', 'pastetext', 'pasteword', 'removeformat', 'charmap', 'outdent', 'indent', 'undo', 'redo', 'wp_help'), $editor_id);
                    $mce_buttons_3 = apply_filters('mce_buttons_3', array(), $editor_id);
                    $mce_buttons_4 = apply_filters('mce_buttons_4', array(), $editor_id);
                }

                $body_class = $editor_id;

                if ($post = get_post()) {
                    $body_class .= ' post-type-' . sanitize_html_class($post->post_type) . ' post-status-' . sanitize_html_class($post->post_status);
                    if (post_type_supports($post->post_type, 'post-formats')) {
                        $post_format = get_post_format($post);
                        if ($post_format && !is_wp_error($post_format))
                            $body_class .= ' post-format-' . sanitize_html_class($post_format);
                        else
                            $body_class .= ' post-format-standard';
                    }
                }

                if (!empty($set['tinymce']['body_class'])) {
                    $body_class .= ' ' . $set['tinymce']['body_class'];
                    unset($set['tinymce']['body_class']);
                }

                if ($set['dfw']) {
                    // replace the first 'fullscreen' with 'wp_fullscreen'
                    if (($key                 = array_search('fullscreen', $mce_buttons)) !== false)
                        $mce_buttons[$key]   = 'wp_fullscreen';
                    elseif (($key                 = array_search('fullscreen', $mce_buttons_2)) !== false)
                        $mce_buttons_2[$key] = 'wp_fullscreen';
                    elseif (($key                 = array_search('fullscreen', $mce_buttons_3)) !== false)
                        $mce_buttons_3[$key] = 'wp_fullscreen';
                    elseif (($key                 = array_search('fullscreen', $mce_buttons_4)) !== false)
                        $mce_buttons_4[$key] = 'wp_fullscreen';
                }

                $mceInit = array(
                    'elements'                => $editor_id,
                    'wpautop'                 => (bool) $set['wpautop'],
                    'remove_linebreaks'       => (bool) $set['wpautop'],
                    'apply_source_formatting' => (bool) !$set['wpautop'],
                    'theme_advanced_buttons1' => implode($mce_buttons, ','),
                    'theme_advanced_buttons2' => implode($mce_buttons_2, ','),
                    'theme_advanced_buttons3' => implode($mce_buttons_3, ','),
                    'theme_advanced_buttons4' => implode($mce_buttons_4, ','),
                    'tabfocus_elements'       => $set['tabfocus_elements'],
                    'body_class'              => $body_class
                );

                // The main editor doesn't use the TinyMCE resizing cookie.
                $mceInit['theme_advanced_resizing_use_cookie'] = 'content' !== $editor_id || empty($set['editor_height']);

                if ($first_run)
                    $mceInit = array_merge(self::$first_init, $mceInit);

                if (is_array($set['tinymce']))
                    $mceInit = array_merge($mceInit, $set['tinymce']);

                // For people who really REALLY know what they're doing with TinyMCE
                // You can modify $mceInit to add, remove, change elements of the config before tinyMCE.init
                // Setting "valid_elements", "invalid_elements" and "extended_valid_elements" can be done through this filter.
                // Best is to use the default cleanup by not specifying valid_elements, as TinyMCE contains full set of XHTML 1.0.
                if ($set['teeny']) {
                    $mceInit = apply_filters('teeny_mce_before_init', $mceInit, $editor_id);
                } else {
                    $mceInit = apply_filters('tiny_mce_before_init', $mceInit, $editor_id);
                }

                if (empty($mceInit['theme_advanced_buttons3']) && !empty($mceInit['theme_advanced_buttons4'])) {
                    $mceInit['theme_advanced_buttons3'] = $mceInit['theme_advanced_buttons4'];
                    $mceInit['theme_advanced_buttons4'] = '';
                }

                self::$mce_settings[$editor_id] = $mceInit;
            } // end if self::$this_tinymce
        }
    }

    
    
endif;