<?php
/**
 * @package WordPress
 * @subpackage Carry Hill
 * 
 * Template Name: Portfolio
 */
require_once( 'archive-portfolio.php' );